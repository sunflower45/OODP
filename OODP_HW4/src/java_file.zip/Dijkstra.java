import java.awt.*;

public class Dijkstra extends AlgorithmAnimator{
    private static int nodeNum=50;         // 노드 수
    private double nodeDis[][];
    static int global = 0;

    public void checkFifty(){
        for(int i=0;i<nodeNum;i++){
            for(int j=0;j<nodeNum;j++) {
                if (nodeDis[i][j] >= 50)
                    nodeDis[i][j] = 0;
                //System.out.println("["+i+"]"+"["+j+"]"+nodeDis[i][j]);
            }
        }
    }


    @Override
    protected void algorithm(Graphics g) {
        readText();
        calDist();
        nodeDis=getArrayDis();
        checkFifty();                       // 50 이상인 애들 걸러내기

        double shortDistance[] = new double[nodeNum + 1];   // 최단 거리를 저장할 변수
        boolean[] check = new boolean[nodeNum + 1];    // 해당 노드 방문 여부
        int arbitStart = 5;                             // 시작 노드, 50이하 아무 값이나 넣어서 돌린다.

        //distance값 초기화.
        for(int i=1;i<nodeNum+1;i++){
            shortDistance[i] = Integer.MAX_VALUE;
        }


        shortDistance[arbitStart]=0;
        check[arbitStart]=true;
        String path="";


        //연결노드 distance갱신
        for(int i=0;i<nodeNum;i++){
            if(!check[i] && nodeDis[arbitStart][i]!=0){
                shortDistance[i] = nodeDis[arbitStart][i];
            }
        }

        for(int j=0;j<nodeNum-1;j++){
            double min=Integer.MAX_VALUE;
            int index=0;
            for(int k=1;k<nodeNum+1;k++){
                if(check[k]==false && shortDistance[k]!=Integer.MAX_VALUE){
                    if(shortDistance[k]<min) {
                        min = shortDistance[k];
                        index = k;
                    }
                }
            }

            check[index]=true;
            path+=index+" ";
            System.out.println("path: "+path);       // 경로 탐색 과정 출력해보기
			
			
            for(int l=0;l<nodeNum;l++){
                if(check[l]==false && nodeDis[index][l]!=0){
                    if(shortDistance[l] > shortDistance[index]+nodeDis[index][l]){
                        shortDistance[l] = shortDistance[index]+nodeDis[index][l];
                    }
                }
            }
        }

        

        
       // for(int i=0;i<nodeNum;i++)
       //     System.out.println("노드"+i+"까지 최소 거리: "+shortDistance[i]);
       // System.out.println("최종 경로 정리해서 출력:"+path);
        
    }
}